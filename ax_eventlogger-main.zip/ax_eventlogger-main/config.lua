Config = {}
Config.Triggerlist = {
  {
    event = 'esx_ambulancejob:revive',
    whook = 'WEBHOOK HIER REIN',
  },
  {
    event = 'esx_taxijob:getMoney',
    whook = 'WEBHOOK HIER REIN',
  },
}
