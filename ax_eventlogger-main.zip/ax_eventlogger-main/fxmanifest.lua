fx_version "adamant"
game "gta5"

author "KattrigerKatta"
server_only "yes"

server_scripts {
    'config.lua',
    'server.lua'
} 